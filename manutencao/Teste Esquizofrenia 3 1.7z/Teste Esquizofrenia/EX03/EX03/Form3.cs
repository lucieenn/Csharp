﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EX03
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            richTextBox1.Text = File.ReadAllText("C:\\ArquivosTabajara\\Itens\\Estoque.txt");
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            File.WriteAllText("C:\\ArquivosTabajara\\Itens\\Estoque.txt", richTextBox1.Text + "\n" + textBox1.Text);
            richTextBox1.Text = File.ReadAllText("C:\\ArquivosTabajara\\Itens\\Estoque.txt");
        }

        public void button1_Click(object sender, EventArgs e)
        {

            Clipboard.SetText(richTextBox1.SelectedText);
            textBox1.Text = Clipboard.GetText();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string parte
            Itemselecionado = listBox1.SelectedItem as string;
            richTextBox1.Text = File.ReadAllText("C:\\ArquivosTabajara\\Itens\\Estoque.txt");
            parte = Itemselecionado.Split().
            listBox1.Items.Add(richTextBox1.Text);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            button2.Enabled = !string.IsNullOrWhiteSpace(textBox1.Text);
        }
    }
}
